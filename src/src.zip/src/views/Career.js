import React from 'react';
import { Row } from 'reactstrap';
import Careerheader from '../components/Career/Careerheader'
import Careercontent from '../components/Career/Careercontent'
import Mainmenu from '../components/Mainmenu2';
import Contact from '../components/landingpagesections/Contact'
function Career() {
  return (
    
   <div>
      <div className="header-white">

      <Mainmenu/>
       
  
      </div>
    <Careerheader/>
  <Careercontent/>
  <Row className="contact">
      <Contact/>
    </Row> 
   </div>
  );
}

export default Career;
