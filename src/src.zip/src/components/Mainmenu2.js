import React, { useState } from 'react';
import logoquad from '../images/logoquad.png';
// import { Link, animateScroll as scroll } from "react-scroll";
import {
  Collapse,
  Navbar,
  NavbarToggler,
  NavbarBrand,
  Nav,
  NavItem,  
  Container,NavLink
} from 'reactstrap';

const Mainmenu = (props) => {
  
  const [isOpen, setIsOpen] = useState(false);

  const toggle = () => setIsOpen(!isOpen);
  
 
  return (
    <Container>
      <Navbar  expand="md" fixed="top" className="shadow-sm">
        <NavbarBrand href="/"> <img src={logoquad} className="logo" alt="logo" /></NavbarBrand>
        <NavbarToggler onClick={toggle} />
        <Collapse isOpen={isOpen} navbar>
       
          <Nav className="ml-auto main-menu" navbar>
            <NavItem>
                 <NavLink href="/home#about-section" activeClass="active"
                    spy={true}  smooth={true}> About Us</NavLink> 
            </NavItem>
            <NavItem>
                <NavLink href="/home#service-section" activeClass="active"
                    spy={true}  smooth={true}> Services</NavLink>
            </NavItem>
            <NavItem>
                <NavLink href="/home#product-section" activeClass="active"
                    spy={true}  smooth={true}> Products</NavLink>
            </NavItem>
            <NavItem>
                <NavLink href="/home#capabilites-section" activeClass="active"
                spy={true}  smooth={true}> Capabilities</NavLink>
            </NavItem>
            <NavItem> 
                <NavLink href="/career" activeClass="active"> Careers</NavLink>  
            </NavItem>
            <NavItem>
                <NavLink href="/home#contact-section" activeClass="active"
                spy={true}  smooth={true}> Contact</NavLink>
            </NavItem>
          </Nav>          
        </Collapse>
      </Navbar>
    </Container>
  );
}

export default Mainmenu;