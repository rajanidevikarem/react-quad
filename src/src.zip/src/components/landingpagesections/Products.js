import React from 'react';

import Qpproduct from '../../images/qpproduct-new.png';

import { Container, Row, Col } from 'reactstrap';
// import { Link } from 'react-router-dom';
function Products() {
  return (
    <Container fluid>
      <div id="product-section">
        <div>
        <Row>
          <Col> <h1 className="product-head text-center"> Products</h1></Col>
        </Row>
        <Row>
          <Col> <div> <h4 className="para text-center mb-5">Platforml is a feature rich Analytics platform enabling:</h4></div></Col>
        </Row>
        <Container>
          <Row className="mt-10">
            <Col xs="6" className="text-center">
              <img src={Qpproduct} className="img-fluid platforml-img" alt="QPlatform" />
            </Col>
            <Col xs="6">
              <ul className="aboutList">
                <li>Access to big data assets including various Hadoop distributions,
                processing engines such as Apache Spark and traditional data sources including RDBMS,
        file servers and Amazon S3 etc.</li>
                <li>Ingestion of data to and from Big Data Repositories</li>
                <li>Perform analytics with custom applications on Hadoop and Spark</li>
                <li>Notebook Integration with private data sources for explorative analytics</li>
                <li>Model Deployment</li>
              </ul>
            </Col>
          </Row>
          <Row className="mb-20">
            <Col className="text-center"><h4>For Product demo please contact us at</h4>
              <a href="mailto:careers@systematrix.ai" className="no-border txt-blu">platforml@quadratics.com</a>
            </Col>
          </Row>
        </Container>
        </div>        
      </div>
      <img src={require("../../images/wave-capb.svg")} alt="wave" className="cabalites-wave" />
    </Container>

  );
}

export default Products;
