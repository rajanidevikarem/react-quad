import React from 'react';
import aboutbg from '../../images/aboutbg.svg';
import { Container, Row, Col } from 'reactstrap';


function About() {
  return (

    <Container fluid>
      <div id="about-section" className="about">
        <Row>
          <Col> <h1 className="about-head text-center"> About us</h1></Col>

        </Row>
        <Row className="about-content">
          <Col md={{ size: 10, offset: 1 }}> <div> <p className="para">Quadratic Systems Inc. founded in 1998 is an Advanced Analytics and digital
          transformation software and services firm based in Chicago, Illinois.
          We are primarily focused on helping our customers adopt and implement a plethora of digital
        transformation opportunities including but not limiting to:</p></div></Col>
        </Row>

        <Row>
          <Col md={{ size: 10, offset: 1 }}>
            <Row>
              <Col md="6">
                <ul className="aboutList">
                  <li>Cloud Adoption</li>
                  <li>Dev Ops</li>
                  <li>Mobile First</li>
                  <li>Pure-play Analytics including </li>
                  <li>Machine Learning and AI</li>
                </ul>
              </Col>
              <Col md="6"> <img src={aboutbg} className="img-md" alt="about" /></Col>
            </Row>
          </Col>
        </Row>
      </div>
    </Container>

  );
}

export default About;
