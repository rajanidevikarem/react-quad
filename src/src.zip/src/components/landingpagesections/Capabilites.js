import React from 'react';
import cloudera from '../../images/capabilites/cloudera.svg';
import aws from '../../images/capabilites/aws.svg';
import docker from '../../images/capabilites/docker.svg';
import jenkins from '../../images/capabilites/jenkins.svg';
import springboot from '../../images/capabilites/springboot.svg';
import scala from '../../images/capabilites/scala.svg';
import Hadoop from '../../images/capabilites/hadoop.svg';
import react from '../../images/capabilites/reactjs.svg';
import angular from '../../images/capabilites/angular.svg';
import { Container, Row, Col } from 'reactstrap';
function Products() {
  return (

    <Container>

      <div>
        <Row>
          <Col> <h1 className="cap-head text-center"> Capabilites</h1></Col>
        </Row>
        <Row>
          <Col>
            <ul className="cap-list">
              <li><img src={cloudera} className="cap-img" alt="logo" /></li>
              <li><img src={aws} className="cap-img" alt="logo" /></li>
              <li><img src={docker} className="cap-img" alt="logo" /></li>
              <li><img src={jenkins} className="cap-img" alt="logo" /></li>
              <li><img src={springboot} className="cap-img" alt="logo" /></li>
              <li><img src={scala} className="cap-img" alt="logo" /></li>
              <li><img src={Hadoop} className="cap-img" alt="logo" /></li>
              <li><img src={react} className="cap-img" alt="logo" /></li>
              <li><img src={angular} className="cap-img" alt="logo" /></li>
            </ul>
          </Col>

        </Row>
      </div>

    </Container>

  );
}

export default Products;
