import React from 'react';
// import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
// import { library } from '@fortawesome/fontawesome-svg-core'
// import { faCheckSquare, faCoffee } from '@fortawesome/free-solid-svg-icons'
import { Container, Row, Col } from 'reactstrap';
function Contact() {
  return (
   
    <Container fluid>
    <div id="contact-section">
    <Row>
    <Col> <h1 className="section-head text-center"> Contact</h1></Col>
   
    </Row>
    
    <Container>
    <Row className="mt-10"> 
   <Col md={{ size: 8, offset: 2 }}>
       <Row>
    <Col md={{ size: 4, offset: 1 }}>
        <div>
        <h3 className="address"> USA</h3>
         <p>1100 E. Woodfield Rd Ste 109</p>
         <p> Schaumburg, IL 60173.</p>
         <p> Ph: 1-847-440-2283 </p>
         </div>
      </Col>
    <Col md="6"> 
    <div className="in-add">
    <h3 className="address"> India</h3>
   <p>5A1 Melange Towers</p> 
   <p>Madhapur, Hyderabad</p>
   <p>Ph: 91-800-815-5200</p>
   </div>
  </Col>
  </Row>
  <p className="text-center txt-blu mt-5"> Copyrights &copy; 2020 Quadratic Systems</p>
  </Col>
    </Row>
   
    </Container>
    </div>
    </Container>

  );
}

export default Contact;
