import React from 'react';
// import Mainmenu from './Mainmenu';
// import cmmi3logo from '../images/cmmi3-logo-light.svg';
import {  Container } from 'reactstrap';

// import { Container, Row, Col } from 'reactstrap';
function Careerheader() {
  return (
    <div className="career-page-header-img">
      <Container fluid>
        <div>
          <div className="page-header-content">
            <div className="content-headtext">
              <h2 className="text-center">Join our team </h2>
            </div>
          </div>
        </div>
      </Container>
    </div>
  );
}
export default Careerheader;
