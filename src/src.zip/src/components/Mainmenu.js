import React, { useState } from 'react';
import logoquad from '../images/logoquad.png';
import { Link} from "react-scroll";
import {
  Collapse,
  Navbar,
  NavbarToggler,
  NavbarBrand,
  Nav,
  NavItem,  
  Container,NavLink
} from 'reactstrap';

const Mainmenu = (props) => {
  
  const [isOpen, setIsOpen] = useState(false);

  const toggle = () => setIsOpen(!isOpen);
  
 
  return (
    <Container>
      <Navbar  expand="md" fixed="top" className="shadow-sm">
        <NavbarBrand href="/"> <img src={logoquad} className="logo" alt="logo" /></NavbarBrand>
        <NavbarToggler onClick={toggle} />
        <Collapse isOpen={isOpen} navbar>
       
          <Nav className="ml-auto main-menu" navbar>
            <NavItem>
              <Link className="nav-link" activeClass="active" to="about-section" 
                spy={true} smooth={true}>About us</Link>
                {/* <NavLink href="#about-section" activeClass="active"
                  spy={true} smooth={true}> About us</NavLink>   */}
            </NavItem>
            <NavItem>
              <Link className="nav-link" activeClass="active" to="service-section"
                spy={true} smooth={true}>Services</Link>
                {/* <NavLink href="#service-section" activeClass="active"
                  spy={true} smooth={true}> Services</NavLink>   */}
            </NavItem>
            <NavItem>
              <Link className="nav-link" activeClass="active"  to="product-section"
                spy={true} smooth={true} offset={-150}>Products</Link>
            </NavItem>
            <NavItem>
              <Link className="nav-link" activeClass="active"  to="capabilites-section"
                spy={true}  smooth={true}  offset={-150}>Capabilities</Link>
            </NavItem>
            <NavItem> 
              {/* <Link className="nav-link" activeClass="active"  to="/career"
                  spy={true}  smooth={true}  offset={-50}>Careers</Link> */}
              <NavLink href="/career" activeClass="active"> Careers</NavLink>  
            </NavItem>
            <NavItem>
              <Link className="nav-link" activeClass="active"  to="contact-section"
                spy={true}  smooth={true}  offset={-50}>Contact</Link>
            </NavItem>
          </Nav>          
        </Collapse>
      </Navbar>
    </Container>
  );
}

export default Mainmenu;